
import dash
from dash import dcc
from dash import html
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

px.set_mapbox_access_token("pk.eyJ1Ijoid2lsbGlhbS10YWxlcm8iLCJhIjoiY2wyM2xmZ3VoMXJncTNpcWRjM3A5ZW5rZCJ9.AA6seVi6IO3k1I334WHxvg")


app = dash.Dash()

df_extranjeros = pd.read_csv("C:/Users/William/Downloads/df_extranjeros_2.csv", 
                 sep = ',',
                 thousands=',', decimal='.',
                 skip_blank_lines=True,
                 low_memory = False)

df_extranjeros_resumen = pd.read_csv("C:/Users/William/Downloads/df_extranjeros_resumen.csv", 
                 sep = ',',
                 thousands=',', decimal='.',
                 skip_blank_lines=True,
                 low_memory = False)




available_año = df_extranjeros_resumen['Año'].unique()
available_Origen = df_extranjeros_resumen['Origen'].unique()
available_CON = df_extranjeros['Continente'].unique()
available_Ciudad=df_extranjeros["Ciudad"].unique()



app.layout = html.Div(
    children=[
        html.H1(children="Proyecto visualizacion de datos",
            style = {
                        'textAlign': 'center',
            }),
        html.H1(children="Entadas de extranjeros a Colombia 2012-2021",style = {
                        'textAlign': 'center',
            }),
        html.P(
            children=
            "William Andres Talero Bermudez y Juan Sebastian Velasquez"
            ),
    html.H4(children='Descripcion de la base'),
    html.P(
            children=
            " La base muestra el consolidado de entradas de extranjeros a Colombia desde el 2012, discriminado por nacionalidad y género"
            ),
    html.H4(children=''),
    html.P(
            children=
            "La intencion de las visualizaciones es mostrar los flujos de extranjeros que llegan a Colombia para identificar tendencias, podemos identificar los destinos turisticos preferentes por continente de origen"
            ),
    html.H4(children=''),
    html.P(
            children=
            ""
            ),
    #Vis1v
    html.Div([
        html.Div([
            html.H1(children='Continente de los extranjeros'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año',
                options=[{'label': i, 'value': i} for i in available_año],
                value=2021
                ),
            dcc.Graph(
                id='example-graph-1'
            ),  
        ], className='six columns'),
        #Vis2v
        html.Div([
            html.H1(children='¿A cual ciudad llegan los extranjeros?'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año2',
                options=[{'label': i, 'value': i} for i in available_año],
                value=2021
                ),
            dcc.Graph(
                id='example-graph-2'
            ),  
        ], className='six columns'),
    ], className='row'),
    html.H4(children='¿Que?'),
    html.P(
            children=
            "**¿QUÉ?:El usuario observa la cantidad de extranjeros que llegaron a Colombia por continente del año 2012 a 2021. "
            ),
    html.H4(children='¿Porque?'),
    html.P(
            children=
            "**¿POR QUÉ?:La tarea que tiene el usuario, es de visualizar la cantidad de extranjeros que llegaron a Colombia, para así identificar posibles tendencias de los continentes de donde provienen los extranjeros. "
            ),
    html.H4(children='¿Como?'),
    html.P(
            children=
            "**¿COMO?: Los modismos utilizados corresponden a un barplot y un treemap"
            ),
    html.Div([
        #Vis3v
        html.Div([
            html.H1(children='Cantidad de extranjeros'),#
            html.Div(children='''
                Origen
            '''),#
            dcc.Dropdown(
                id='crossfilter_origen',
                options=[{'label': i, 'value': i} for i in available_Origen],
                value="América del Sur"
                ),
            dcc.Graph(
                id='example-graph-3'
            ),  
        ], className='six columns'),
        #Vis 4v
        html.Div([
            html.H1(children='Cantidad de extranjeros en %'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_continente4v',
                options=[{'label': i, 'value': i} for i in available_CON],
                value="Antartida"
                ),
            dcc.Graph(
                id='example-graph-4v'
            ),  
        ], className='six columns'),
    ], className='row'),
    html.H4(children='¿Que?'),
    html.P(
            children=
            "**¿QUÉ?:El usuario observa la cantidad de extranjeros que llegaron a Colombia por continente del año 2012 a 2021."
            ),
    html.H4(children='¿Porque?'),
    html.P(
            children=
            "**¿POR QUÉ?:La tarea que tiene el usuario, es de visualizar la cantidad de extranjeros que llegaron a Colombia, para así identificar posibles tendencias de los continentes de donde provienen los extranjeros."
            ),
    html.H4(children='¿Como?'),
    html.P(
            children=
            "**¿COMO?: los modismos utilizados corresponden a un linechart y un piechart"
            ),
    #Vis5v
    html.Div([
        html.Div([
            html.H1(children='Cantidad de extranjeros'),#
            html.Div(children='''
                Ciudad
            '''),#
            dcc.Dropdown(
                id='crossfilter_ciudad5v',
                options=[{'label': i, 'value': i} for i in available_Ciudad],
                value="Bogotá"
                ),
            dcc.Graph(
                id='example-graph-5v'
            ),  
        ], className='six columns'),
        #Vis 6v
        html.Div([
            html.H1(children='Cantidad de extanjeros en %'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_continente6v',
                options=[{'label': i, 'value': i} for i in available_Ciudad],
                value="Bogotá"
                ),
            dcc.Graph(
                id='example-graph-6v'
            ),  
        ], className='six columns'),
    ], className='row'),
    html.H4(children='¿Que?'),
    html.P(
            children=
            "**¿QUÉ?:El usuario observa la cantidad de extranjeros que llegaron a Colombia por continente del año 2012 a 2021."
            ),
    html.H4(children='¿Porque?'),
    html.P(
            children=
            "**¿POR QUÉ?:La tarea que tiene el usuario, es de visualizar la cantidad de extranjeros que llegaron a Colombia, para así identificar posibles tendencias de los continentes de donde provienen los extranjeros."
            ),
    html.H4(children='¿Como?'),
    html.P(
            children=
            "**¿COMO?: Los modismos utilizados  corresponden a un barplot y un linechart"
            ),
    #Vis 7v
    html.Div([
        html.Div([
            html.H1(children='Cantidad de extranjeros por ciudad'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año7v',
                options=[{'label': i, 'value': i} for i in available_año],
                value=2021
                ),
            dcc.Graph(
                id='example-graph-7v'
            ),  
        ], className='six columns'), 
        #Vis8v
        html.Div([
            html.H1(children='Cantidad de extranjeros por continente'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año8v',
                options=[{'label': i, 'value': i} for i in available_año],
                value=2021
                ),
            dcc.Graph(
                id='example-graph-8v'
            ),  
        ], className='six columns'),
    ], className='row'),
    html.H4(children='¿Que?'),
    html.P(
            children=
            "**¿QUÉ?:El usuario observa los puntos donde la gran mayoría de extranjeros llegaron a Colombia."
            ),
    html.H4(children='¿Porque?'),
    html.P(
            children=
            "**¿POR QUÉ?:La tarea del usuario, es visualizar cuáles fueron los puntos donde fue más frecuente la llegada de extranjeros, para así identificar qué ciudades de Colombia son las que reciben un mayor flujo de inmigración."
            ),
    html.H4(children='¿Como?'),
    html.P(
            children=
            "**¿COMO?:Los modismos utilizados corresponden a mapas de burbujas"
            ),
    #Vis 5
    html.Div([
        html.Div([
            html.H1(children='Bonus'),#
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año4',
                options=[{'label': i, 'value': i} for i in available_año],
                value=2021
                ),
            html.Div(children='''
                
                Continente
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_continente2',
                options=[{'label': i, 'value': i} for i in available_CON],
                value="América del Sur"
                ),
            dcc.Graph(
                id='example-graph-5'
            ),  
        ], className='six columns'),
    ], className='row')
])

## Viz 1
@app.callback(
    dash.dependencies.Output('example-graph-1', 'figure'),
    [dash.dependencies.Input('crossfilter_año', 'value')]
    )

def update_graph(año_value):
    df_extranjeros_año = df_extranjeros_resumen[df_extranjeros_resumen['Año'] == año_value]

    fig = px.bar(df_extranjeros_año,x="CON",y="Origen",color="Origen"
                )
    fig.update_layout(
    height=600,
    title_text='Cantidad de extranjeros por continente')


    return fig

## Viz 2
@app.callback(
    dash.dependencies.Output('example-graph-2', 'figure'),
    [dash.dependencies.Input('crossfilter_año2', 'value')]
    )

def update_graph(año_value2):
    df_extranjeros_año = df_extranjeros[df_extranjeros['Año#'] == año_value2]

    fig2 = px.treemap(df_extranjeros_año, path=["Continente",'Ciudad'],
                 values='Total',
                )
    fig2.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig2

## Viz 3
@app.callback(
    dash.dependencies.Output('example-graph-3', 'figure'),
    [dash.dependencies.Input('crossfilter_origen', 'value')]
    )

def update_graph(Origen_value):
    df_extranjeros_origen = df_extranjeros_resumen[df_extranjeros_resumen['Origen'] == Origen_value]

    fig3 = px.line(df_extranjeros_origen, x="Año", y="CON", color='Origen')              
    fig3.update_layout(
    height=600,
    title_text='Cantidad de extranjeros de 2012-2021')


    return fig3
## Viz 4v
@app.callback(
    dash.dependencies.Output('example-graph-4v', 'figure'),
    [dash.dependencies.Input('crossfilter_continente4v', 'value')]
    )

def update_graph(CON_value):
    df_extranjeros_CON = df_extranjeros[df_extranjeros['Continente'] == CON_value]

    fig4v = px.pie(df_extranjeros_CON,values="Total",names="Ciudad"
                )
    fig4v.update_layout(
    height=600,
    title_text=' % de Cantidad de extranjeros por ciudad 2012-2021')


    return fig4v
## Viz 5v
@app.callback(
    dash.dependencies.Output('example-graph-5v', 'figure'),
    [dash.dependencies.Input('crossfilter_ciudad5v', 'value')]
    )

def update_graph(Ciudad5v_value):
    df_extranjeros_ciudad5v = df_extranjeros[df_extranjeros['Ciudad'] == Ciudad5v_value]

    fig5v = px.bar(df_extranjeros_ciudad5v, x="Año", y="Total", color='Ciudad')              
    fig5v.update_layout(
    height=600,
    title_text='Cantidad de extranjeros de 2012-2021')


    return fig5v
## Viz 6v
@app.callback(
    dash.dependencies.Output('example-graph-6v', 'figure'),
    [dash.dependencies.Input('crossfilter_continente6v', 'value')]
    )

def update_graph(CIUDAD_value):
    df_extranjeros_Ci = df_extranjeros[df_extranjeros['Ciudad'] == CIUDAD_value]

    fig6v = px.pie(df_extranjeros_Ci,values="Total",names="Continente"
                )
    fig6v.update_layout(
    height=600,
    title_text='% Cantidad de extranjeros por continente 2012-2021')


    return fig6v
## Viz 7v
@app.callback(
    dash.dependencies.Output('example-graph-7v', 'figure'),
    [dash.dependencies.Input('crossfilter_año7v', 'value')]
    )

def update_graph(Año_value3):
    df_extranjeros_año3 = df_extranjeros[df_extranjeros['Año#'] == Año_value3]
    fig7v = px.scatter_mapbox(df_extranjeros_año3,
                        lat='Latitud',
                        lon='Longitud',
                        hover_name='Ciudad',
                        zoom=4,
                        color="Ciudad",
                        size="Total", 
                        center = {"lat": 4.570868, "lon": -74.297333})
    fig7v.update_layout(
        title_text = 'Cantidad de extranjeros en Colombia',
        showlegend = True,
        geo = dict(
            scope = 'south america',
            landcolor = 'rgb(217, 217, 217)',
        )
    )


    return fig7v
## Viz 8v
@app.callback(
    dash.dependencies.Output('example-graph-8v', 'figure'),
    [dash.dependencies.Input('crossfilter_año8v', 'value')]
    )

def update_graph(Año_value3):
    df_extranjeros_año3 = df_extranjeros[df_extranjeros['Año#'] == Año_value3]
    fig8v = px.scatter_mapbox(df_extranjeros_año3,
                        lat='Latitud',
                        lon='Longitud',
                        hover_name='Ciudad',
                        zoom=4,
                        color="Continente",
                        size="Total", 
                        center = {"lat": 4.570868, "lon": -74.297333})
    fig8v.update_layout(
        title_text = 'Cantidad de extranjeros por Continnte en Colombia',
        showlegend = True,
        geo = dict(
            scope = 'south america',
            landcolor = 'rgb(217, 217, 217)',
        )
    )


    return fig8v
## Viz 5 
@app.callback(
    dash.dependencies.Output('example-graph-5', 'figure'),
    [dash.dependencies.Input('crossfilter_año4', 'value'),
     dash.dependencies.Input('crossfilter_continente2', 'value')]
    )

def update_graph(año_value,continente_value):
    df_extranjeros_con = df_extranjeros[df_extranjeros['Continente'] == continente_value]
    df_extranjeros_año5 = df_extranjeros_con[df_extranjeros_con['Año#'] == año_value]

    fig5 = px.bar(df_extranjeros_año5,x="Total",y="Ciudad",color="Ciudad"
                )
    fig5.update_layout(
    height=600,
    title_text='Cantidad de extranjeros por año y continente')


    return fig5




if __name__=='__main__':
     app.run_server(debug=True)
